// SetUpTest.java
package test.java.BaseMethods;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.*;

import java.net.MalformedURLException;

public class SetUpTest {
    protected WebDriver driver;
    private InitializeBrowser browserInitiator;

    @Parameters("browser")
    @BeforeMethod
    public void setUp(@Optional("CHROME") String browser) throws MalformedURLException {
        browserInitiator = new InitializeBrowser();
        driver = browserInitiator.getDriver(browser);
        browserInitiator.navigateToURL("https://localhost/LEAF_Request_Portal/admin");
    }

    @AfterMethod
    public void tearDown(){
        if (browserInitiator !=null){
            browserInitiator.quitBrowser();
        }
    }
}
