// SetUpTest.java
package test.java.BaseMethods;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.*;

import java.net.MalformedURLException;

public class SetUpTest {
    protected WebDriver driver;
    private InitializeBrowser browserInitiator;

    @Parameters({ "env", "browser","remote_url"})
    @BeforeMethod
    public void setUp(String env, @Optional("CHROME") String browser, @Optional("") String remote_url) throws MalformedURLException {

        browserInitiator = new InitializeBrowser();
        if(remote_url.equalsIgnoreCase("")){
            driver = browserInitiator.getDriver(browser);
        }else{
            driver = browserInitiator.getRemoteDriver(remote_url);
        }
        browserInitiator.navigateToURL(env);
        System.out.println("Title: "+driver.getCurrentUrl()+" -->"+driver.getTitle());
    }

    @AfterMethod(alwaysRun = true)
    public void tearDown(){
        if (browserInitiator !=null){
            browserInitiator.quitBrowser();
        }
    }
}
