// SetUpTest.java
package test.java.BaseMethods;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.*;

import java.net.MalformedURLException;

public class SetUpTest {
    protected WebDriver driver;
    private InitializeBrowser browserInitiator;

    @Parameters({"browser","remote_url"})
    @BeforeMethod
    public void setUp(@Optional("CHROME") String browser, @Optional("") String remote_url) throws MalformedURLException {

        browserInitiator = new InitializeBrowser();
        if(remote_url.equalsIgnoreCase("")){
            driver = browserInitiator.getDriver(browser);
        }else{
            driver = browserInitiator.getRemoteDriver(remote_url);
        }
        browserInitiator.navigateToURL("https://localhost/LEAF_Request_Portal/admin");
    }

    @AfterMethod(alwaysRun = true)
    public void tearDown(){
        if (browserInitiator !=null){
            browserInitiator.quitBrowser();
        }
    }
}
