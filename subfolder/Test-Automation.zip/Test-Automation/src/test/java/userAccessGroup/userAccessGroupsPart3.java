package test.java.userAccessGroup;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.NoSuchElementException;
import org.testng.annotations.BeforeClass;

import java.util.Random;

import test.java.Framework.AppVariables;
import test.java.Framework.setupFramework;
import test.java.Framework.waitMethods;
import test.java.Framework.highlightElement;


public class userAccessGroupsPart3 extends setupFramework {

	
	public String sRand;
	public String groupNum;
	public String nexusURL = "https://localhost/LEAF_Nexus/?a=view_group&groupID=";
	public String portalURL = "https://localhost/LEAF_Request_Portal/admin/?a=mod_groups";
	public String id;		
	public WebDriver driverNexus, driverPortal;

	
	
	
	
	private static WebDriver chromeLoginNexus(String env) {	  //Step 3 - call from createNexusDriver()
		System.out.println("Launching Chrome");  //Step Over until - return driver;
		System.setProperty("webdriver.chrome.driver", test.java.Framework.AppVariables.CHROMEDRIVER);
		
		
			if (AppVariables.headless) {
				ChromeOptions options = new ChromeOptions();
				options.addArguments("--headless", "--disable-gpu", "--window-size=1920,1200",
						"--ignore-certificate-errors", "--disable-extensions", "--no-sandbox",
						"--disable-dev-shm-usage");
				WebDriver driverNexus = new ChromeDriver(options);
				driverNexus.navigate().to(env);
				System.out.println("Driver established for: " + driverNexus.getClass());
				return driverNexus;  //HEADLESS driver

			} else {
				WebDriver driverNexus = new ChromeDriver();
				driverNexus.manage().window().maximize();
				driverNexus.navigate().to(env);  
				System.out.println("Driver established using: " + driverNexus.getClass());
				
				return driverNexus;  

			}
	}	

	
	private void testForNexusCertPage() /*throws InterruptedException */ {
	    try {
	    	waitMethods.waiter(waitMethods.w300);
	    	WebElement ele = driverNexus.findElement(By.id("details-button"));  //.click();
	    	highlightElement.highLightElement(driverNexus, ele);
	    	ele.click();

	    	waitMethods.waiter(waitMethods.w300);
	    	
	        WebElement ele2 = driverNexus.findElement(By.partialLinkText("Proceed to localhost")); 
	        highlightElement.highLightElement(driverNexus, ele2);
	    	ele2.click();
	        System.out.println("Nexus Certificate not found, proceeding to unsecure site");
	    } catch (NoSuchElementException e) {
	        System.out.println("Nexus Certificate present, proceeding ");
	    } 
	} 
	
	
	public WebDriver getDriverNexus() {		// Called from setUp() in @BeforeClass				
        return driverNexus;					//Establish ChromeDriver for Nexus
	}							

	
	
	 
	public void createNexusDriver() {		// Step 2 - called by createNexusDriver1()
		String NexusURL = nexusURL + id;
		System.out.println("NexusURL: " + NexusURL);
	
		driverNexus = chromeLoginNexus(NexusURL);
		//driverNexus = chromeLoginNexus("https://localhost/LEAF_Nexus/?a=view_group&groupID=" + id);
		waitMethods.waiter(waitMethods.w2k);
		testForNexusCertPage();
		System.out.println("Chromedriver for Nexus created");
	}
	

					// TODO:  parameterize method to accept String URL
	public void createPortalDriver() {		// Step 2 - called by  a new method to be created like createNexusDriver1()
		String NexusURL = portalURL;
		System.out.println("NexusURL: " + NexusURL);
	
		driverNexus = chromeLoginNexus(NexusURL);
		waitMethods.waiter(waitMethods.w2k);
		testForNexusCertPage();
		System.out.println("Chromedriver for Nexus created");
	}
	
	
	public void closeDownMainPortal() {
		
		driver.quit();
		System.out.println("setupFramework reached @AfterClass, driver.quit()");
		//System.out.println("Method closeDownMainPortal() Disabled - browser remains open");
	}
	
	
	public void closeDownNexus() {
		
		driverNexus.quit();
		System.out.println("setupFramework reached @AfterClass, driverNexus.quit()");
		//System.out.println("Method closeDownNexus() Disabled - browser remains open");
	}
	
	
	public String generateRand() {
    	Random random = new Random();
    	Integer rand = random.nextInt(999999);
    	sRand = rand.toString();
    	
    	System.out.println("sRand = " + sRand);

    	return sRand;
    	
	}
	
	
	@BeforeMethod
	@BeforeClass
	public void setUp()  {			//Starts Here
		if(driver!= null) {
			driver=getDriver();   //   from test.java.Framework.setupFramework
		}
		if(driverNexus!= null) {
			driverNexus=getDriverNexus();   
		}		
	}
	

	
	
	//***************** Tests Begin *******************************************************
	
	@Test(priority = 1) //MUST REMAIN #1 ( or zero) -test for certificate - if no, click Advanced -> Proceed
	private void testForCertPage() /*throws InterruptedException */ {
	    try {
	    	//waitMethods.implicitWait(waitMethods.w300);
	    	waitMethods.waiter(waitMethods.w300);
	    	WebElement ele = driver.findElement(By.id("details-button"));  //.click();
	    	highlightElement.highLightElement(driver, ele);
	    	ele.click();

	    	waitMethods.waiter(waitMethods.w300);
	    	
	        WebElement ele2 = driver.findElement(By.partialLinkText("Proceed to localhost")); 
	        highlightElement.highLightElement(driver, ele2);
	    	ele2.click();
	        System.out.println("Certificate not found, proceeding to unsecure site");
	    } catch (NoSuchElementException e) {
	        System.out.println("Certificate present, proceeding ");
	    } 
	} 
 
	
	
	@Test(priority = 4040) //
	private void openAccessGroup() {
		//System.out.println("Before opening Group\ngroupNum = " + groupNum);
		waitMethods.waiter(waitMethods.w2k);    //  "Test User Access Group " + groupNum
		WebElement ele = driver.findElement(By.xpath("/html/body/div[1]/div/div[1]/main/div[4]/div/div/div[1]"));		
		highlightElement.highLightElement(driver, ele); 
	    ele.click();
	    System.out.println("Opened Test User Group ");
	} 
	

	 
	
	
	@Test(priority = 4060) //						Pickup here: ERR HERE - Local
	private void deleteUserGroup() {
		waitMethods.waiter(waitMethods.w1k);
		//WebElement ele = driver.findElement(By.xpath("//*[contains(text(),'Delete Group')]"));
		WebElement ele = driver.findElement(By.xpath("/html/body/div[3]/div[2]/form/div/main/div[1]/div[2]/button"));	
	    highlightElement.highLightElement(driver, ele);
	    ele.click();
	    System.out.println("Delete User Group");
	} 
	
	
	@Test(priority = 4080) //						ERR HERE - Local
	private void confirmYes() {			
		waitMethods.waiter(waitMethods.w500);
		WebElement ele = driver.findElement(By.id("confirm_button_save"));
        highlightElement.highLightElement(driver, ele);  
        ele.click();		
        waitMethods.waiter(waitMethods.w100);
        System.out.println("Confirmed action");
	} 
	
	
	
//	@Test(priority = 4100)
//	public void closeDownMainPortal2() {
//		closeDownMainPortal();
//	}
	


	


	
	
}  //class userAccessGroupsPart3
