package test.java.Framework;

public class TestData {

	//Search InputBox   BS = Basic Search;  AS = Advanced Search
//	public final static String SB_XP = "//*[@id=\"LeafFormSearch560_searchtxt\"]";
//	public final static String SB_NAME= "searchtxt";
//	public final static String SB_BLANK = "";		//can a .clear method be used
//	public final static String SB_VALUE = "test automation";
//	public final static String SB_REQNUM = "576";
	
	//Home page
//	public final static String S_BASIC_N = "searchtxt";			//Basic - Search Inputbox

			
	
}
