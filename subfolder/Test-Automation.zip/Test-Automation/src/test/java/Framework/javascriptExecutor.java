package test.java.Framework;


public class javascriptExecutor {

	
	
	
	/*
	JavascriptExecutor Js1 = (JavascriptExecutor) driver;
	Js1.executeScript("window.scrollBy(0,1000)");                   //scroll 1000 pixel vertical
	*/

	
//	public static void javascriptExecutor(WebDriver driver, WebElement jsEle) {
//		
//		JavascriptExecutor jsEle = (JavascriptExecutor) driver;
//		
//		jsEle.executeScript("window.scrollBy(0,1000)")
//	}
	
	
	
	
//  HIGHLIGHT ELEMENT CODE	
//	public static void highLightElement(WebDriver driver, WebElement ele) {
//		int i = 0;	
//		int j = 50;
//		if (AppVariables.demoMode) {   //Set T/F in test.java.Framework.AppVariables.demoMode
//			JavascriptExecutor js = (JavascriptExecutor) driver; 
//		 
//			for(i = 0; i <3; i++) {
//				//if(i == 3) {j =200;}
//					js.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: 2px solid red;');", ele);
//					waitMethods.waiter(j);
//				 
//					js.executeScript("arguments[0].setAttribute('style','border: solid 2px white');", ele);
//					waitMethods.waiter(j);
//				//}
//			
//			}
//		}
//	}
	
	
	
} //class
