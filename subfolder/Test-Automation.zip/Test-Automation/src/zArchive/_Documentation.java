package zArchive;

public class _Documentation {

	
/*
 * Copy OuterHTML
 * Copy Selector
 * Copy JS Path
 * Copy Styles
 * Copy XPath
 * Copy full XPath

 	
 	//Search input	
	<input style="border: 1px solid black; padding: 4px" type="text" id="LeafFormSearch271_searchtxt" 
		name="searchtxt" size="50" title="Enter your search text" value="">
	
	//Date Sort
	<th id="LeafFormGrid857_header_date" tabindex="0" style="text-align: center; cursor: pointer; border: 1px solid black; "
	"padding: 4px 2px; font-size: 12px; background-color: rgb(209, 223, 255);
	">Date<span id="LeafFormGrid857_header_date_sort" class="LeafFormGrid857_sort" style="display: none;"></span></th>
	
	
	//Title Sort
	<th id="LeafFormGrid857_header_title" tabindex="0" style="text-align: center; cursor: pointer; border: 1px solid black; 
	padding: 4px 2px; font-size: 12px; background-color: rgb(209, 223, 255);
	">Title<span id="LeafFormGrid857_header_title_sort" class="LeafFormGrid857_sort" style="display: none;"></span></th>
	
	//Service Sort
	<th id="LeafFormGrid857_header_service" tabindex="0" style="text-align: center; cursor: pointer; border: 1px solid black; 
	padding: 4px 2px; font-size: 12px; background-color: rgb(209, 223, 255);
	">Service<span id="LeafFormGrid857_header_service_sort" class="LeafFormGrid857_sort" style="display: none;"></span></th>
	
	//Status Sort
	<th id="LeafFormGrid857_header_currentStatus" tabindex="0" style="text-align: center; cursor: pointer; border: 1px solid black; 
	padding: 4px 2px; font-size: 12px; background-color: rgb(209, 223, 255);
	">Status<span id="LeafFormGrid857_header_currentStatus_sort" class="LeafFormGrid857_sort" style="display: none;"></span></th>
	
	//Left-most Govt logo
	 * <img src="images/VA_icon_small.png" style="width: 80px" alt="VA logo">
	
	
	
	
*/
}
