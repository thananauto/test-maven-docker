package zArchive;



public class CreateXML {
/*
 Now we will execute them using 'testng.xml' file. We will add the classes which we want to test.


Remember we need to pass the parameters 'browserType' and 'appURL' for the base Setup class.

 <!DOCTYPE suite SYSTEM "http://testng.org/testng-1.0.dtd">

<suite name="Page Object test example">

<parameter name="appURL" value="https://www.google.co.in/">

<parameter name="browserType" value="firefox"/>

<test name="sample test">

<classes>

<class name="com.pack.common.tests.HomePageTest"/>

<class name="com.pack.common.tests.SignInPageTest"/>

<class name="com.pack.common.tests.CreateAnAccounTest"/>

</classes>

</test>

</suite>


The above Page Object Model framework is the simple one without using any Build tools, Loggers, Listeners 
and Utilities. In the next coming post we will add all these things and design a Robust Page Object Model 
test.java.Framework which are used in the Industry.


  
 
 * */
	
	
	
	
} //Class
