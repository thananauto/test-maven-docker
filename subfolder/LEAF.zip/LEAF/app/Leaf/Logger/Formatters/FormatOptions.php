<?php

namespace App\Leaf\Logger\Formatters;

class FormatOptions
{
    const READ_COLUMN_NAMES = "READCOLUMNNAME";
    const DISPLAY = "DISPLAY";
}
