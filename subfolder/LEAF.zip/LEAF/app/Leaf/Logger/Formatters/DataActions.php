<?php

namespace App\Leaf\Logger\Formatters;

class DataActions
{
    const MODIFY = 'modify';
    const DELETE = 'delete';
    const ADD = 'add';
    const IMPORT = 'import';
    const RESTORE = 'restore';
    const CREATE = 'create';
    const MERGE = 'merge';
    const PRUNE = 'prune';
}
